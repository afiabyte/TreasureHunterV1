"""
GameEngine: Core coordinator for Treasure Hunter tactical evasion simulation.

Manages:
- Game states: HOME, HOW_TO_PLAY, PLAYING, GAME_OVER.
- 60 FPS clock cycle with zero I/O blocking.
- Linear Interpolation (LERP) rendering math at speed = 0.28 for fluid entity movement.
- Input dispatching (WASD/Arrows, [H] hunter spawn, [B] barrier shift, [R] reset, ESC return).
- Non-blocking coordination with GeminiTacticalAI worker threads.
- SQLite match persistence via DatabaseManager.
- Procedural audio feedback integration via SoundManager.
"""

import os
import sys
import time
import asyncio
from typing import Optional, Dict, Any, List, Tuple
import pygame

# Universal cross-platform font patch for WebAssembly, mobile browsers, and headless runners
_orig_sysfont = pygame.font.SysFont

def _safe_sysfont(name: str, size: int, bold: bool = False, italic: bool = False) -> pygame.font.Font:
    try:
        f = _orig_sysfont(name, size, bold=bold, italic=italic)
        if f is not None:
            return f
    except Exception:
        pass
    try:
        f = pygame.font.Font(None, size)
        f.set_bold(bold)
        f.set_italic(italic)
        return f
    except Exception:
        return pygame.font.Font(None, size)

pygame.font.SysFont = _safe_sysfont

from database import DatabaseManager
from ai_tactical import GeminiTacticalAI
from environment import GridEnvironment
from ui_manager import UIManager
from sound_effects import SoundManager



# Game State Identifiers
STATE_SPLASH = "SPLASH"
STATE_CREATE_ACCOUNT = "CREATE_ACCOUNT"
STATE_LOGIN = "LOGIN"
STATE_HOME = "HOME"
STATE_SETTINGS = "SETTINGS"
STATE_HISTORY = "HISTORY"
STATE_HOW_TO_PLAY = "HOW_TO_PLAY"
STATE_LEVEL_SELECT = "LEVEL_SELECT"
STATE_PLAYING = "PLAYING"
STATE_PAUSED = "PAUSED"
STATE_GAME_OVER = "GAME_OVER"


class GameEngine:
    """
    Main Game Engine driving the 60 FPS event loop, state machine,
    rendering pipeline, and AI thread communication.
    """

    def __init__(self, screen_width: int = 960, screen_height: int = 780, db_path: str = "dungeon_records.db") -> None:
        """
        Initialize Pygame, display surfaces, sound mixer, and modular sub-components.

        Args:
            screen_width: Window width in pixels (default: 960).
            screen_height: Window height in pixels (default: 780).
            db_path: Path to SQLite persistence database file.
        """
        # Initialize Pygame core modules
        pygame.init()
        pygame.display.set_caption("Treasure Hunter // Tactical Evasion")

        self.screen_width = screen_width
        self.screen_height = screen_height
        self.screen = pygame.display.set_mode((self.screen_width, self.screen_height))
        self.clock = pygame.time.Clock()
        self.is_running = True

        # State Machine Initialization (Begins with Splash Intro, then User Login)
        self.state = STATE_SPLASH
        self.return_state = STATE_HOME
        self.splash_timer: float = 0.0
        self.splash_duration: float = 2.5
        self.auth_mode: str = "create_account"
        self.auth_status: str = ""
        self.is_auth_error: bool = False
        self.current_user: str = ""
        self.user_stats: Optional[Dict[str, Any]] = None
        self.login_status: str = "AWAITING CREDENTIALS"
        self.recent_operatives: List[Dict[str, Any]] = []

        # Subsystem Managers (Clean zero-circular dependency architecture)
        self.db = DatabaseManager(db_path)
        self.ai = GeminiTacticalAI()
        self.ui = UIManager(self.screen_width, self.screen_height)
        self.sound = SoundManager()

        # Query recent operatives and persistent settings from SQLite
        self.recent_operatives = self.db.get_recent_operatives(3)
        self.settings = self.db.get_settings()
        self.settings_sfx: bool = self.settings.get("sound_effects", "true").lower() == "true"
        self.settings_bgm: bool = self.settings.get("background_music", "false").lower() == "true"
        self.settings_ai_hints: bool = self.settings.get("ai_commander_hints", "true").lower() == "true"
        self.settings_move_animation: str = self.settings.get("move_animation", "SMOOTH")
        self.settings_status: str = ""
        self.is_api_connected: bool = bool(getattr(self.ai, "api_key", None) or os.environ.get("GEMINI_API_KEY"))

        # Synchronize UI widgets with persistent settings
        self.ui.toggle_sfx.is_on = self.settings_sfx
        self.ui.toggle_bgm.is_on = self.settings_bgm
        self.ui.toggle_ai_hints.is_on = self.settings_ai_hints
        self.ui.sound_enabled = self.settings_sfx
        if hasattr(self.sound, "sound_enabled"):
            self.sound.sound_enabled = self.settings_sfx
        if hasattr(self.sound, "music_enabled"):
            self.sound.music_enabled = self.settings_bgm
            if self.settings_bgm:
                self.sound.play_music("menu")

        # Configurable Game Parameters (set from Home screen)
        self.selected_grid_size: int = 7
        self.selected_level: int = 2
        self.player_name: str = "OPERATIVE-01"

        # Active Environment Simulation
        self.env: Optional[GridEnvironment] = None

        # Standby Reconnaissance Phase (prevents game starting abruptly)
        self.standby_timer: float = 0.0

        # Game Over Status Tracking
        self.is_victory: bool = False
        self.is_new_best_record: bool = False
        self.best_victory_steps: Optional[int] = self.db.get_best_victory_steps(self.current_user)

        # Visual Grid Geometry Cache (origin_x, origin_y, cell_size)
        self.origin_x: float = 0.0
        self.origin_y: float = 0.0
        self.cell_size: float = 64.0

        # AI Dispatch Throttling & Telemetry
        self.ai_request_timer: float = 0.0
        self.ai_request_interval: float = 0.35  # Poll/refresh interval for AI guidance
        self.cached_recommended_path: List[List[int]] = []
        self.cached_commander_order: str = "Mission initialized. Commencing tactical evasion."
        self.cached_hunter_moves: List[str] = []

    def start_mission(self, grid_size: int, level: int, player_name: str) -> None:
        """
        Transition from HOME to PLAYING state.
        Instantiates a fresh GridEnvironment with zero memory leaks.

        Args:
            grid_size: Chosen N dimension (5, 7, 9, 11).
            level: Chosen difficulty tier (1: Recruit, 2: Tactical, 3: Nightmare).
            player_name: Operative callsign string.
        """
        self.selected_grid_size = grid_size
        self.selected_level = level
        self.player_name = player_name.strip() if player_name.strip() else "OPERATIVE-01"

        # Instantiate fresh procedural environment
        self.env = GridEnvironment(grid_size=self.selected_grid_size, level=self.selected_level)

        # Compute dynamic visual geometry to ensure grid scales above HUD
        self.origin_x, self.origin_y, self.cell_size = self.ui.compute_grid_geometry(self.selected_grid_size)

        # Synchronize pixel coordinates and snap entities into position
        self.env.sync_pixel_targets(self.origin_x, self.origin_y, self.cell_size)
        self.env.snap_visuals_to_targets()

        # Query active operative profile and best score from SQLite for HUD display
        self.user_stats = self.db.get_operative(self.player_name)
        self.best_victory_steps = self.db.get_best_victory_steps(self.player_name)

        # Reset AI caches and timers
        self.cached_recommended_path = []
        self.cached_commander_order = "Objective: Infiltrate, acquire Key, evade Hunter drones."
        self.cached_hunter_moves = []
        self.ai_request_timer = 0.0

        # Standby Reconnaissance Phase (3.0s buffer so game never starts abruptly)
        self.standby_timer = 3.0

        # Transition state and start dungeon infiltration soundtrack
        self.state = STATE_PLAYING
        self.sound.play_music("dungeon")

        # Dispatch immediate tactical query to background worker
        self._dispatch_ai_query()

    def _dispatch_ai_query(self) -> None:
        """
        Package the current N x N grid telemetry and dispatch a non-blocking
        asynchronous request to GeminiTacticalAI.
        """
        if not self.env:
            return

        hunter_positions = [h.pos for h in self.env.hunters]
        hunter_facings = [h.facing for h in self.env.hunters]
        wall_positions = list(self.env.walls)

        # Non-blocking async invocation via background worker thread
        self.ai.request_tactical_decision(
            grid_size=self.env.grid_size,
            player_pos=self.env.player_pos,
            hunter_positions=hunter_positions,
            hunter_facings=hunter_facings,
            wall_positions=wall_positions,
            key_pos=self.env.key_pos,
            has_key=self.env.has_key,
            exit_pos=self.env.exit_pos,
        )

    def _trigger_victory(self) -> None:
        """Handle mission victory state transition and database persistence."""
        self.is_victory = True
        self.sound.play_victory()

        # Save match result to SQLite on the basis of active operative with chamber level and grid metadata
        steps_taken = self.env.steps if self.env else 0
        current_chamber = getattr(self.ui, "selected_chamber_level", 1)
        mode_name = self.env.config["name"] if self.env and "name" in self.env.config else "TACTICAL"
        self.db.save_match_result(
            self.player_name,
            steps_taken,
            "VICTORY",
            level_num=current_chamber,
            grid_size=self.selected_grid_size,
            difficulty=mode_name,
        )
        self.user_stats = self.db.get_operative(self.player_name)

        # Evaluate if this run sets a new personal best record
        prev_best = self.best_victory_steps
        if prev_best is None or steps_taken < prev_best:
            self.is_new_best_record = True
            self.best_victory_steps = steps_taken
        else:
            self.is_new_best_record = False

        self.state = STATE_GAME_OVER

    def _trigger_defeat(self) -> None:
        """Handle mission defeat (hunter interception) and database persistence."""
        self.is_victory = False
        self.is_new_best_record = False
        self.sound.play_defeat()

        # Save match result to SQLite on the basis of active operative with chamber level and grid metadata
        steps_taken = self.env.steps if self.env else 0
        current_chamber = getattr(self.ui, "selected_chamber_level", 1)
        mode_name = self.env.config["name"] if self.env and "name" in self.env.config else "TACTICAL"
        self.db.save_match_result(
            self.player_name,
            steps_taken,
            "DEFEAT",
            level_num=current_chamber,
            grid_size=self.selected_grid_size,
            difficulty=mode_name,
        )
        self.user_stats = self.db.get_operative(self.player_name)

        self.state = STATE_GAME_OVER

    # =========================================================================
    # EVENT HANDLING & INPUT DISPATCHING
    # =========================================================================
    def handle_events(self) -> None:
        """Poll and handle all Pygame input events."""
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                self.is_running = False
                return

            if self.state == STATE_SPLASH:
                self._handle_splash_events(event)
            elif self.state == STATE_CREATE_ACCOUNT:
                self._handle_create_account_events(event)
            elif self.state == STATE_LOGIN:
                if getattr(self, "auth_mode", "create_account") == "create_account":
                    self._handle_create_account_events(event)
                else:
                    self._handle_login_events(event)
            elif self.state == STATE_HOME:
                self._handle_home_events(event)
            elif self.state == STATE_SETTINGS:
                self._handle_settings_events(event)
            elif self.state == STATE_HISTORY:
                self._handle_history_events(event)
            elif self.state == STATE_LEVEL_SELECT:
                self._handle_level_select_events(event)
            elif self.state == STATE_HOW_TO_PLAY:
                self._handle_how_to_play_events(event)
            elif self.state == STATE_PLAYING:
                self._handle_playing_events(event)
            elif self.state == STATE_PAUSED:
                self._handle_paused_events(event)
            elif self.state == STATE_GAME_OVER:
                self._handle_game_over_events(event)

    def _handle_splash_events(self, event: pygame.event.Event) -> None:
        """Handle inputs on the Splash Screen (Space/Enter/Click transitions to Login)."""
        if event.type in (pygame.MOUSEBUTTONDOWN, pygame.KEYDOWN):
            self.state = STATE_LOGIN
            self.auth_mode = "login"
            self.ui.input_login_username.is_active = True
            self.recent_operatives = self.db.get_recent_operatives(3)

    def _handle_create_account_events(self, event: pygame.event.Event) -> None:
        """Handle inputs on the Create Account Screen."""
        # 1. Tab key navigation between form fields
        if event.type == pygame.KEYDOWN and event.key == pygame.K_TAB:
            if self.ui.input_reg_username.is_active:
                self.ui.input_reg_username.is_active = False
                self.ui.input_reg_email.is_active = True
            elif self.ui.input_reg_email.is_active:
                self.ui.input_reg_email.is_active = False
                self.ui.input_reg_password.is_active = True
            elif self.ui.input_reg_password.is_active:
                self.ui.input_reg_password.is_active = False
                self.ui.input_reg_confirm_password.is_active = True
            else:
                self.ui.input_reg_confirm_password.is_active = False
                self.ui.input_reg_username.is_active = True
            return

        # 2. Dispatch event to active text inputs
        self.ui.input_reg_username.handle_event(event)
        self.ui.input_reg_email.handle_event(event)
        self.ui.input_reg_password.handle_event(event)
        self.ui.input_reg_confirm_password.handle_event(event)

        # 3. Check Back to Login button
        if self.ui.btn_back_to_login.handle_event(event):
            self.auth_mode = "login"
            self.ui.input_login_username.is_active = True
            self.recent_operatives = self.db.get_recent_operatives(3)
            self.sound.play_key()
            return

        # 4. Check Register button or Enter Key on inputs
        do_register = False
        if self.ui.btn_register.handle_event(event):
            do_register = True
        elif event.type == pygame.KEYDOWN and event.key in (pygame.K_RETURN, pygame.K_KP_ENTER):
            do_register = True

        if do_register:
            u = self.ui.input_reg_username.text.strip()
            e = self.ui.input_reg_email.text.strip()
            p1 = self.ui.input_reg_password.text
            p2 = self.ui.input_reg_confirm_password.text

            # If all inputs are blank and enter was pressed
            if not u and not e and not p1 and not p2:
                self.auth_status = "PLEASE ENTER REGISTRATION DETAILS"
                self.is_auth_error = True
                return

            # Validation
            if not u:
                self.auth_status = "USERNAME CANNOT BE EMPTY"
                self.is_auth_error = True
                return
            if len(u) < 3:
                self.auth_status = "USERNAME MUST BE AT LEAST 3 CHARACTERS"
                self.is_auth_error = True
                return
            if not e or "@" not in e or "." not in e:
                self.auth_status = "PLEASE ENTER A VALID EMAIL ADDRESS"
                self.is_auth_error = True
                return
            if not p1 or len(p1) < 4:
                self.auth_status = "PASSWORD MUST BE AT LEAST 4 CHARACTERS"
                self.is_auth_error = True
                return
            if p1 != p2:
                self.auth_status = "PASSWORDS DO NOT MATCH"
                self.is_auth_error = True
                return

            ok, msg, op = self.db.register_account(u, e, p1)
            if not ok:
                self.auth_status = msg
                self.is_auth_error = True
            else:
                self.auth_status = "ACCOUNT CREATED SUCCESSFULLY!"
                self.is_auth_error = False
                self.current_user = op["username"]
                self.player_name = self.current_user
                self.ui.input_player_name.text = self.current_user
                self.user_stats = op
                self.best_victory_steps = self.db.get_best_victory_steps(self.current_user)
                self.sound.play_key()
                self.state = STATE_HOME
                return

    def _handle_login_events(self, event: pygame.event.Event) -> None:
        """Handle inputs on the Operative Login Screen."""
        # 0. Check switch to Create Account
        if self.ui.btn_login_switch_to_register.handle_event(event):
            self.auth_mode = "create_account"
            self.ui.input_reg_username.is_active = True
            self.sound.play_key()
            return

        # Tab navigation between username and password
        if event.type == pygame.KEYDOWN and event.key == pygame.K_TAB:
            if self.ui.input_login_username.is_active:
                self.ui.input_login_username.is_active = False
                self.ui.input_login_password.is_active = True
            else:
                self.ui.input_login_password.is_active = False
                self.ui.input_login_username.is_active = True
            return

        self.ui.input_login_username.handle_event(event)
        self.ui.input_login_password.handle_event(event)

        # Check Forgot Password button
        if self.ui.btn_forgot_password.handle_event(event):
            target = self.ui.input_login_username.text.strip()
            if target:
                self.login_status = f"HINT: Credentials logged for {target}"
            else:
                self.login_status = "HINT: Default test passphrase is 'secret123'"
            self.sound.play_key()
            return

        # 1. Check quick-select click on recent operatives in card
        if event.type == pygame.MOUSEBUTTONDOWN and event.button == 1:
            mx, my = event.pos
            card_x = self.screen_width // 2 - 255
            card_y = 224
            if self.recent_operatives and len(self.recent_operatives) > 0:
                rx = card_x + 36
                ry = card_y + 165
                for op in self.recent_operatives[:3]:
                    op_rect = pygame.Rect(rx, ry, 136, 34)
                    if op_rect.collidepoint(mx, my):
                        self.ui.input_login_username.text = op["username"]
                        self.login_status = f"SELECTED: {op['username']}"
                        break
                    rx += 148

        # 2. Check Login Submit button or Enter Key
        do_login = False
        target_name = self.ui.input_login_username.text.strip()
        target_pass = self.ui.input_login_password.text

        if self.ui.btn_login_submit.handle_event(event):
            do_login = True
        elif event.type == pygame.KEYDOWN and event.key in (pygame.K_RETURN, pygame.K_KP_ENTER):
            do_login = True

        if do_login:
            if not target_name:
                self.login_status = "PLEASE ENTER A USERNAME"
                self.is_auth_error = True
                return
            if target_pass:
                ok, msg, op = self.db.authenticate_user(target_name, target_pass)
                if not ok:
                    self.login_status = msg
                    return
            else:
                op = self.db.login_or_register_operative(target_name)

            self.current_user = op["username"]
            self.player_name = self.current_user
            self.ui.input_player_name.text = self.current_user
            self.user_stats = op
            self.best_victory_steps = self.db.get_best_victory_steps(self.current_user)
            self.sound.play_key()
            self.state = STATE_HOME
            return

        # 3. Check Guest Login Button
        if self.ui.btn_login_guest.handle_event(event):
            op = self.db.login_or_register_operative("GUEST-01")
            self.current_user = op["username"]
            self.player_name = self.current_user
            self.ui.input_player_name.text = self.current_user
            self.user_stats = op
            self.best_victory_steps = self.db.get_best_victory_steps(self.current_user)
            self.sound.play_key()
            self.state = STATE_HOME
            return

    def _handle_home_events(self, event: pygame.event.Event) -> None:
        """Handle inputs on the Main Menu parchment scroll."""
        # 0. Handle Exit Confirmation Modal if open
        if getattr(self.ui, "show_exit_modal", False):
            if self.ui.btn_exit_confirm.handle_event(event):
                self.is_running = False
                return
            if self.ui.btn_exit_cancel.handle_event(event) or (event.type == pygame.KEYDOWN and event.key in (pygame.K_ESCAPE, pygame.K_n)):
                self.ui.show_exit_modal = False
                self.sound.play_step()
                return
            if event.type == pygame.KEYDOWN and event.key in (pygame.K_RETURN, pygame.K_KP_ENTER, pygame.K_y):
                self.is_running = False
                return
            if event.type == pygame.MOUSEBUTTONDOWN and event.button == 1:
                cx = self.screen_width // 2
                card_w = min(564, self.screen_width - 32)
                card_h = 388
                card_y = 318 if self.screen_height >= 1000 else max(16, (self.screen_height - card_h) // 2)
                card_x = cx - card_w // 2
                card_rect = pygame.Rect(card_x, card_y, card_w, card_h)
                if not card_rect.collidepoint(event.pos):
                    self.ui.show_exit_modal = False
                    self.sound.play_step()
                    return
            return

        # 1. Handle Levels Modal clicks if open
        if getattr(self.ui, "show_levels_modal", False):
            if self.ui.btn_close_modal.handle_event(event) or (event.type == pygame.KEYDOWN and event.key == pygame.K_ESCAPE):
                self.ui.show_levels_modal = False
                return
            if event.type == pygame.MOUSEBUTTONDOWN and event.button == 1:
                mx, my = event.pos
                cx = self.screen_width // 2
                cols = 5
                cell_w = 66
                cell_h = 52
                gap = 14
                grid_w = cols * cell_w + (cols - 1) * gap
                grid_start_x = cx - grid_w // 2
                mh = 270
                my_card = max(20, (self.screen_height - mh) // 2)
                grid_start_y = my_card + 65
                victories = self.user_stats.get("victories", 0) if self.user_stats else 0
                user_level = max(1, min(10, 1 + victories))
                for lvl in range(1, 11):
                    idx = lvl - 1
                    r = idx // cols
                    c = idx % cols
                    cell_x = grid_start_x + c * (cell_w + gap)
                    cell_y = grid_start_y + r * (cell_h + gap)
                    c_rect = pygame.Rect(cell_x, cell_y, cell_w, cell_h)
                    if c_rect.collidepoint(mx, my) and lvl <= user_level:
                        self.ui.selected_chamber_level = lvl
                        diff = 1 if lvl <= 3 else (2 if lvl <= 7 else 3)
                        self.selected_level = diff
                        for b in self.ui.level_buttons:
                            b.is_selected = (int(b.tag) == diff)
                        self.ui.show_levels_modal = False
                        self.sound.play_step()
                        return
            return

        # 2. Handle Settings Modal clicks if open
        if getattr(self.ui, "show_settings_modal", False):
            if self.ui.btn_close_modal.handle_event(event) or (event.type == pygame.KEYDOWN and event.key == pygame.K_ESCAPE):
                self.ui.show_settings_modal = False
                return
            if self.ui.btn_toggle_sfx.handle_event(event):
                self.ui.sound_enabled = not self.ui.sound_enabled
                if hasattr(self.sound, "sound_enabled"):
                    self.sound.sound_enabled = self.ui.sound_enabled
                return
            if self.ui.btn_modal_switch_user.handle_event(event):
                self.ui.show_settings_modal = False
                self.recent_operatives = self.db.get_recent_operatives(3)
                self.login_status = f"SWITCHING FROM {self.current_user}"
                self.ui.input_login_username.is_active = True
                self.state = STATE_LOGIN
                return
            return

        # 3. Text input field for player callsign
        self.ui.input_player_name.handle_event(event)
        # Dynamically sync active operative's DB stats (best steps, level) as player types
        current_input = self.ui.input_player_name.text.strip()
        if current_input and current_input != self.player_name:
            self.player_name = current_input
            self.current_user = current_input
            self.user_stats = self.db.get_operative(current_input)
            self.best_victory_steps = self.db.get_best_victory_steps(current_input)

        # 4. Grid size selector buttons (5x5, 7x7 default, 9x9, 11x11)
        for btn in self.ui.grid_buttons:
            if btn.handle_event(event):
                for b in self.ui.grid_buttons:
                    b.is_selected = False
                btn.is_selected = True
                self.selected_grid_size = int(btn.tag)
                self.sound.play_step()

        # 5. Level / Difficulty selector buttons (1: Recruit, 2: Tactical, 3: Nightmare)
        for btn in self.ui.level_buttons:
            if btn.handle_event(event):
                for b in self.ui.level_buttons:
                    b.is_selected = False
                btn.is_selected = True
                self.selected_level = int(btn.tag)
                self.sound.play_step()

        # 6. "Start Mission" button
        if self.ui.btn_start_mission.handle_event(event):
            callsign = self.ui.input_player_name.text.strip()
            if not callsign:
                callsign = self.current_user
            self.sound.play_key()
            self.start_mission(
                grid_size=self.selected_grid_size,
                level=self.selected_level,
                player_name=callsign,
            )
            return

        # 7. "Levels (1-50)" button
        if hasattr(self.ui, "btn_levels") and self.ui.btn_levels.handle_event(event):
            self.return_state = STATE_HOME
            self.state = STATE_LEVEL_SELECT
            self.sound.play_step()
            return

        # 7b. Click on LEVEL badge on Parchment Header
        if event.type == pygame.MOUSEBUTTONDOWN and event.button == 1:
            mx, my = event.pos
            cx = self.screen_width // 2
            level_badge_rect = pygame.Rect(cx + 9, 172, 180, 34)
            if level_badge_rect.collidepoint(mx, my):
                self.return_state = STATE_HOME
                self.state = STATE_LEVEL_SELECT
                self.sound.play_step()
                return

            # 7c. Click on BEST TROPHY badge on Parchment Header -> Opens Dungeon Records
            trophy_badge_rect = pygame.Rect(cx - 189, 172, 180, 34)
            if trophy_badge_rect.collidepoint(mx, my):
                self.return_state = STATE_HOME
                self.state = STATE_HISTORY
                self.sound.play_step()
                return

        # 8. "How to Play" button
        if self.ui.btn_how_to_play.handle_event(event):
            self.return_state = STATE_HOME
            self.state = STATE_HOW_TO_PLAY
            self.sound.play_step()
            return

        # 8b. "History" button in 2x2 grid
        if hasattr(self.ui, "btn_history") and self.ui.btn_history.handle_event(event):
            self.return_state = STATE_HOME
            self.state = STATE_HISTORY
            self.sound.play_step()
            return

        # 9. "Settings" button
        if hasattr(self.ui, "btn_settings") and self.ui.btn_settings.handle_event(event):
            self.return_state = STATE_HOME
            self.state = STATE_SETTINGS
            self.settings_status = ""
            self.sound.play_step()
            return

        # 10. "Exit" button or ESC opens Exit Confirmation Modal
        if (hasattr(self.ui, "btn_exit") and self.ui.btn_exit.handle_event(event)) or (event.type == pygame.KEYDOWN and event.key == pygame.K_ESCAPE):
            self.ui.show_exit_modal = True
            self.sound.play_step()
            return

        # 11. Switch User / Logout button returns to Login screen
        if self.ui.btn_logout.handle_event(event):
            self.recent_operatives = self.db.get_recent_operatives(3)
            self.login_status = f"SWITCHING FROM {self.current_user}"
            self.ui.input_login_username.is_active = True
            self.state = STATE_LOGIN
            return

    def _handle_settings_events(self, event: pygame.event.Event) -> None:
        """Handle inputs on the Retro-Pixel RPG Settings Screen."""
        if event.type == pygame.KEYDOWN and event.key == pygame.K_ESCAPE:
            self.state = getattr(self, "return_state", STATE_HOME)
            self.sound.play_step()
            return

        # 1. SFX Toggle Switch
        if self.ui.toggle_sfx.handle_event(event):
            self.settings_sfx = self.ui.toggle_sfx.is_on
            self.sound.sound_enabled = self.settings_sfx
            self.ui.sound_enabled = self.settings_sfx
            self.sound.play_step()
            return

        # 2. BGM Toggle Switch
        if self.ui.toggle_bgm.handle_event(event):
            self.settings_bgm = self.ui.toggle_bgm.is_on
            if hasattr(self.sound, "music_enabled"):
                self.sound.music_enabled = self.settings_bgm
                if self.settings_bgm:
                    self.sound.play_music("menu")
                else:
                    self.sound.stop_music()
            self.sound.play_step()
            return

        # 3. AI Commander Hints Toggle Switch
        if self.ui.toggle_ai_hints.handle_event(event):
            self.settings_ai_hints = self.ui.toggle_ai_hints.is_on
            self.sound.play_step()
            return

        # 4. Move Animation Selector (SMOOTH vs FAST)
        if self.ui.btn_anim_smooth.handle_event(event):
            self.settings_move_animation = "SMOOTH"
            self.sound.play_step()
            return

        if self.ui.btn_anim_fast.handle_event(event):
            self.settings_move_animation = "FAST"
            self.sound.play_step()
            return

        # 5. "SAVE & APPLY" button
        if self.ui.btn_settings_save.handle_event(event):
            self.sound.sound_enabled = self.settings_sfx
            self.sound.music_enabled = self.settings_bgm
            if self.settings_bgm:
                self.sound.play_music("menu")
            else:
                self.sound.stop_music()

            self.db.save_settings({
                "sound_effects": "true" if self.settings_sfx else "false",
                "background_music": "true" if self.settings_bgm else "false",
                "ai_commander_hints": "true" if self.settings_ai_hints else "false",
                "move_animation": self.settings_move_animation,
            })
            self.settings_status = "SETTINGS SAVED & APPLIED!"
            self.sound.play_key()
            self.state = getattr(self, "return_state", STATE_HOME)
            return

        # 6. "BACK TO MENU" button
        if self.ui.btn_settings_back.handle_event(event):
            self.state = getattr(self, "return_state", STATE_HOME)
            self.sound.play_step()
            return

    def _handle_history_events(self, event: pygame.event.Event) -> None:
        """Handle inputs on the Dungeon Records Screen."""
        if event.type == pygame.KEYDOWN and event.key == pygame.K_ESCAPE:
            self.state = getattr(self, "return_state", STATE_HOME)
            self.sound.play_step()
            return

        if self.ui.btn_history_back.handle_event(event):
            self.state = getattr(self, "return_state", STATE_HOME)
            self.sound.play_step()
            return

    def _handle_level_select_events(self, event: pygame.event.Event) -> None:
        """Handle inputs on the 1-50 Select Level screen."""
        if event.type == pygame.KEYDOWN and event.key == pygame.K_ESCAPE:
            self.state = self.return_state
            return

        # 1. Back button returns to Home screen
        if hasattr(self.ui, "btn_level_back") and self.ui.btn_level_back.handle_event(event):
            self.state = self.return_state
            self.sound.play_step()
            return

        # 2. Check clicks on Level Tiles
        victories = self.user_stats.get("victories", 0) if self.user_stats else 0
        unlocked_max = max(1, min(10, 1 + victories))

        for btn in getattr(self.ui, "level_tile_buttons", []):
            if btn.handle_event(event):
                try:
                    lvl = int(btn.tag)
                    if lvl <= unlocked_max:
                        self.ui.selected_chamber_level = lvl
                        diff = 1 if lvl <= 3 else (2 if lvl <= 7 else 3)
                        self.selected_level = diff
                        for b in self.ui.level_buttons:
                            b.is_selected = (int(b.tag) == diff)
                        self.sound.play_step()
                except ValueError:
                    pass
                return

        # 3. Play Level Button launches mission with corresponding difficulty
        if hasattr(self.ui, "btn_level_play") and self.ui.btn_level_play.handle_event(event):
            lvl = getattr(self.ui, "selected_chamber_level", 1)
            diff = 1 if lvl <= 3 else (2 if lvl <= 7 else 3)
            self.selected_level = diff
            callsign = self.ui.input_player_name.text.strip() if hasattr(self.ui, "input_player_name") else self.current_user
            if not callsign:
                callsign = self.current_user
            self.sound.play_key()
            self.start_mission(
                grid_size=self.selected_grid_size,
                level=self.selected_level,
                player_name=callsign,
            )
            return

    def _handle_how_to_play_events(self, event: pygame.event.Event) -> None:
        """Handle inputs on the How to Play Screen."""
        if event.type == pygame.KEYDOWN and event.key == pygame.K_ESCAPE:
            self.state = self.return_state
            return

        if self.ui.btn_back_to_menu.handle_event(event):
            self.state = self.return_state

    def _handle_playing_events(self, event: pygame.event.Event) -> None:
        """Handle in-game inputs during active mission."""
        if not self.env:
            return

        # 0. Check Exit Confirmation Modal if open during gameplay
        if getattr(self.ui, "show_exit_modal", False):
            if self.ui.btn_exit_confirm.handle_event(event) or (event.type == pygame.KEYDOWN and event.key in (pygame.K_RETURN, pygame.K_KP_ENTER, pygame.K_y)):
                self.ui.show_exit_modal = False
                self.best_victory_steps = self.db.get_best_victory_steps(self.player_name)
                self.state = STATE_HOME
                self.sound.play_music("menu")
                return
            if self.ui.btn_exit_cancel.handle_event(event) or (event.type == pygame.KEYDOWN and event.key in (pygame.K_ESCAPE, pygame.K_n)):
                self.ui.show_exit_modal = False
                self.sound.play_step()
                return
            return

        # Check Click on Top-Right Pause Button
        if self.ui.btn_pause.handle_event(event):
            self.state = STATE_PAUSED
            return

        if event.type == pygame.KEYDOWN:
            # P, ESC, or Pause key: Toggle tactical pause
            if event.key in (pygame.K_p, pygame.K_PAUSE, pygame.K_ESCAPE):
                self.state = STATE_PAUSED
                return

            # SPACE: Skip standby if active, or toggle pause
            if event.key == pygame.K_SPACE:
                if self.standby_timer > 0:
                    self.standby_timer = 0.0
                else:
                    self.state = STATE_PAUSED
                return

            # [R]: Reset mission with clean layout and fresh standby buffer
            if event.key == pygame.K_r:
                self.env.reset_environment()
                self.env.sync_pixel_targets(self.origin_x, self.origin_y, self.cell_size)
                self.env.snap_visuals_to_targets()
                self.standby_timer = 3.0
                self._dispatch_ai_query()
                return

            # [H]: Manually deploy a hunter drone reinforcement (up to 8 max)
            if event.key == pygame.K_h:
                if len(self.env.hunters) < 8:
                    spawned = self.env.spawn_hunter()
                    if spawned:
                        self.env.sync_pixel_targets(self.origin_x, self.origin_y, self.cell_size)
                        self.sound.play_spawn()
                        self._dispatch_ai_query()
                return

            # [B]: Manually trigger dynamic barrier shift
            if event.key == pygame.K_b:
                self.env.relocate_walls()
                self.sound.play_shift()
                self._dispatch_ai_query()
                return

            # Player Cardinal Movement (WASD / Arrow Keys)
            dr, dc = 0, 0
            if event.key in (pygame.K_w, pygame.K_UP):
                dr, dc = -1, 0
            elif event.key in (pygame.K_s, pygame.K_DOWN):
                dr, dc = 1, 0
            elif event.key in (pygame.K_a, pygame.K_LEFT):
                dr, dc = 0, -1
            elif event.key in (pygame.K_d, pygame.K_RIGHT):
                dr, dc = 0, 1

            if dr != 0 or dc != 0:
                # If moving during standby, immediately commence active mission
                if self.standby_timer > 0:
                    self.standby_timer = 0.0

                was_key_secured = self.env.has_key
                moved = self.env.move_player(dr, dc)
                if moved:
                    self.sound.play_move()
                    # Play sound when Key is collected
                    if not was_key_secured and self.env.has_key:
                        self.sound.play_key()

                    # Update player target pixel center
                    self.env.sync_pixel_targets(self.origin_x, self.origin_y, self.cell_size)

                    # Check defeat (stepped directly onto a hunter)
                    if self.env.check_defeat():
                        self._trigger_defeat()
                        return

                    # Check victory (reached exit with key)
                    if self.env.check_victory():
                        self._trigger_victory()
                        return

                    # Trigger fresh AI decision request for the new position
                    self._dispatch_ai_query()

    def _handle_paused_events(self, event: pygame.event.Event) -> None:
        """Handle inputs while the game is in Tactical Pause state."""
        # 0. Check Exit Confirmation Modal if open during pause
        if getattr(self.ui, "show_exit_modal", False):
            if self.ui.btn_exit_confirm.handle_event(event) or (event.type == pygame.KEYDOWN and event.key in (pygame.K_RETURN, pygame.K_KP_ENTER, pygame.K_y)):
                self.ui.show_exit_modal = False
                self.best_victory_steps = self.db.get_best_victory_steps(self.player_name)
                self.state = STATE_HOME
                self.sound.play_music("menu")
                return
            if self.ui.btn_exit_cancel.handle_event(event) or (event.type == pygame.KEYDOWN and event.key in (pygame.K_ESCAPE, pygame.K_n)):
                self.ui.show_exit_modal = False
                self.sound.play_step()
                return
            return

        # Top-right button or Resume button resumes gameplay
        if self.ui.btn_pause.handle_event(event) or self.ui.btn_pause_resume.handle_event(event):
            self.state = STATE_PLAYING
            return

        if event.type == pygame.KEYDOWN and event.key in (pygame.K_p, pygame.K_ESCAPE, pygame.K_SPACE):
            self.state = STATE_PLAYING
            return

        # Restart sector
        if self.ui.btn_pause_restart.handle_event(event) or (event.type == pygame.KEYDOWN and event.key == pygame.K_r):
            self.start_mission(self.selected_grid_size, self.selected_level, self.player_name)
            return

        # Settings from Pause
        if (hasattr(self.ui, "btn_pause_settings") and self.ui.btn_pause_settings.handle_event(event)) or self.ui.btn_pause_help.handle_event(event):
            self.return_state = STATE_PAUSED
            self.state = STATE_SETTINGS
            self.sound.play_step()
            return

        # Return to Home Menu
        if self.ui.btn_pause_menu.handle_event(event):
            self.best_victory_steps = self.db.get_best_victory_steps(self.player_name)
            self.state = STATE_HOME
            self.sound.play_music("menu")
            return

    def _handle_game_over_events(self, event: pygame.event.Event) -> None:
        """Handle inputs on the Victory and Defeat overlays."""
        if self.is_victory:
            # Keyboard shortcuts: [R] for Play Again, [ESC] for Main Menu
            if event.type == pygame.KEYDOWN:
                if event.key == pygame.K_r:
                    self.start_mission(self.selected_grid_size, self.selected_level, self.player_name)
                    return
                elif event.key == pygame.K_ESCAPE:
                    self.best_victory_steps = self.db.get_best_victory_steps(self.player_name)
                    self.state = STATE_HOME
                    self.sound.play_music("menu")
                    return

            # Advance to Next Level (Seamless progression: Recruit -> Tactical -> Nightmare & Chamber 1-10)
            if self.ui.btn_next_level.handle_event(event):
                next_lvl = self.selected_level + 1 if self.selected_level < 3 else self.selected_level
                self.selected_level = next_lvl
                self.ui.selected_chamber_level = min(10, getattr(self.ui, "selected_chamber_level", 1) + 1)
                # Update level button highlights on home screen
                for b in self.ui.level_buttons:
                    b.is_selected = (int(b.tag) == next_lvl)
                self.start_mission(self.selected_grid_size, next_lvl, self.player_name)
                return

            # Replay current level
            if self.ui.btn_victory_replay.handle_event(event):
                self.start_mission(self.selected_grid_size, self.selected_level, self.player_name)
                return

            # Return to Home Menu
            if self.ui.btn_victory_menu.handle_event(event):
                self.best_victory_steps = self.db.get_best_victory_steps(self.player_name)
                self.state = STATE_HOME
                self.sound.play_music("menu")
                return
        else:
            # Retry level on defeat (Click or [R])
            if self.ui.btn_retry_level.handle_event(event) or (event.type == pygame.KEYDOWN and event.key == pygame.K_r):
                self.start_mission(self.selected_grid_size, self.selected_level, self.player_name)
                return

            # Return to Home Menu (Click or [ESC])
            if self.ui.btn_defeat_menu.handle_event(event) or (event.type == pygame.KEYDOWN and event.key == pygame.K_ESCAPE):
                self.best_victory_steps = self.db.get_best_victory_steps(self.player_name)
                self.state = STATE_HOME
                self.sound.play_music("menu")
                return

    # =========================================================================
    # SIMULATION UPDATE & LERP ANIMATION (60 FPS)
    # =========================================================================
    def update(self, dt: float) -> None:
        """
        Advance simulation timers, execute LERP coordinate updates,
        and synchronize with background AI decisions.

        Args:
            dt: Delta time elapsed since last frame in seconds.
        """
        self.ui.update(dt)

        if self.state == STATE_SPLASH:
            self.splash_timer += dt
            if self.splash_timer >= self.splash_duration:
                self.state = STATE_LOGIN
                self.auth_mode = "create_account"
                self.ui.input_reg_username.is_active = True
                self.recent_operatives = self.db.get_recent_operatives(3)
            return

        if self.state in (STATE_LOGIN, STATE_CREATE_ACCOUNT):
            self.ui.input_reg_username.update(dt)
            self.ui.input_reg_email.update(dt)
            self.ui.input_reg_password.update(dt)
            self.ui.input_reg_confirm_password.update(dt)
            self.ui.input_login_username.update(dt)
            return

        if self.state == STATE_PAUSED:
            # Complete simulation freeze while paused
            return

        if self.state == STATE_PLAYING and self.env:
            # Standby reconnaissance phase: allows player to inspect board before enemies move
            if self.standby_timer > 0:
                self.standby_timer = max(0.0, self.standby_timer - dt)
                # Keep LERP visual coordinates smoothly aligned
                self.env.update_lerp_all(speed=0.28)
                return

            # 1. Update Environment Timers (Dynamic walls, Hunter spawn, Hunter move)
            wall_relocated, hunter_spawned, hunter_move_triggered = self.env.update_timers(dt)

            if wall_relocated:
                self.sound.play_shift()
                self._dispatch_ai_query()

            if hunter_spawned:
                self.sound.play_spawn()
                self.env.sync_pixel_targets(self.origin_x, self.origin_y, self.cell_size)
                self._dispatch_ai_query()

            # 2. Fetch Latest Asynchronous AI Decision (Non-blocking)
            decision, latency_ms, status_text, is_busy = self.ai.get_latest_decision()
            if decision.get("recommended_path"):
                self.cached_recommended_path = decision["recommended_path"]
            if decision.get("commander_order"):
                self.cached_commander_order = decision["commander_order"]
            if decision.get("hunter_moves"):
                self.cached_hunter_moves = decision["hunter_moves"]

            # 3. Hunter Movement Cadence Tick
            if hunter_move_triggered:
                # Apply latest AI hunter moves
                if self.cached_hunter_moves:
                    self.env.apply_hunter_moves(self.cached_hunter_moves)
                else:
                    # Emergency fallback if no moves queued
                    self.env.apply_hunter_moves(["STAY"] * len(self.env.hunters))

                # Update target pixel positions for LERP
                self.env.sync_pixel_targets(self.origin_x, self.origin_y, self.cell_size)

                # Check if any hunter intercepted the player
                if self.env.check_defeat():
                    self._trigger_defeat()
                    return

                # Request fresh moves for the next tick
                self._dispatch_ai_query()

            # 4. Periodic AI Refresh Timer (keeps telemetry and breadcrumbs fresh)
            self.ai_request_timer += dt
            if self.ai_request_timer >= self.ai_request_interval:
                self.ai_request_timer = 0.0
                if not is_busy:
                    self._dispatch_ai_query()

            # 5. Entity LERP Visual Updates (speed depends on move animation setting)
            lerp_speed = 0.55 if getattr(self, "settings_move_animation", "SMOOTH") == "FAST" else 0.28
            self.env.update_lerp_all(speed=lerp_speed)

    # =========================================================================
    # RENDERING PIPELINE
    # =========================================================================
    def render(self) -> None:
        """Render the complete scene based on the current state."""
        self.screen.fill((11, 15, 23))

        if self.state == STATE_SPLASH:
            self.ui.draw_splash_screen(self.screen, self.splash_timer, self.splash_duration)

        elif self.state == STATE_CREATE_ACCOUNT or (self.state == STATE_LOGIN and getattr(self, "auth_mode", "create_account") == "create_account"):
            self.ui.draw_create_account_screen(self.screen, status_msg=self.auth_status, is_status_error=self.is_auth_error)

        elif self.state == STATE_LOGIN:
            self.ui.draw_login_screen(self.screen, self.recent_operatives, self.login_status)

        elif self.state == STATE_HOME:
            self.ui.draw_home_screen(self.screen, self.best_victory_steps, self.user_stats)
            if getattr(self.ui, "show_exit_modal", False):
                self.ui.draw_exit_modal(self.screen)

        elif self.state == STATE_SETTINGS:
            self.ui.draw_settings_screen(
                self.screen,
                is_smooth_selected=(getattr(self, "settings_move_animation", "SMOOTH") == "SMOOTH"),
                is_api_connected=bool(getattr(self.ai, "api_key", None) or getattr(self, "is_api_connected", False)),
                status_message=getattr(self, "settings_status", ""),
            )

        elif self.state == STATE_HISTORY:
            active_player = self.player_name or self.current_user
            summary = self.db.get_dungeon_records_summary(player_name=active_player)
            self.ui.draw_history_screen(
                self.screen,
                win_rate=summary["win_rate"],
                best_steps=summary["best_steps"],
                records=summary["records"],
                player_name=active_player,
            )

        elif self.state == STATE_HOW_TO_PLAY:
            self.ui.draw_how_to_play_screen(self.screen)

        elif self.state == STATE_LEVEL_SELECT:
            self.ui.draw_level_select_screen(self.screen, self.user_stats)

        elif self.state in (STATE_PLAYING, STATE_PAUSED, STATE_GAME_OVER) and self.env:
            # 1. Draw Grid Area and Entities
            self.ui.draw_grid_environment(
                surface=self.screen,
                grid_size=self.env.grid_size,
                origin_x=self.origin_x,
                origin_y=self.origin_y,
                cell_size=self.cell_size,
                walls=self.env.walls,
                player_x=self.env.player_visual_x,
                player_y=self.env.player_visual_y,
                player_pos=self.env.player_pos,
                has_key=self.env.has_key,
                key_pos=self.env.key_pos,
                exit_pos=self.env.exit_pos,
                hunters=self.env.hunters,
                recommended_path=self.cached_recommended_path,
                wall_shift_alert=self.env.wall_shift_alert,
                player_facing=(self.env.player_facing_dr, self.env.player_facing_dc),
            )

            # 2. Draw Bottom HUD Console
            decision, latency_ms, status_text, _ = self.ai.get_latest_decision()
            level_name = self.env.config["name"]
            self.ui.draw_hud_console(
                surface=self.screen,
                level_name=level_name,
                steps=self.env.steps,
                best_steps=self.best_victory_steps,
                has_key=self.env.has_key,
                ai_latency_ms=latency_ms,
                ai_status=status_text,
                is_gemini_active=self.ai.is_gemini_active,
                commander_order=self.cached_commander_order,
            )

            # 3. Draw Quick Pause Button (visible during active mission & pause)
            self.ui.btn_pause.draw(self.screen)

            # 4. Draw Standby Banner if in reconnaissance countdown
            if self.state == STATE_PLAYING and self.standby_timer > 0:
                self.ui.draw_standby_banner(self.screen, self.standby_timer)

            # 5. Draw Tactical Pause Overlay
            if self.state == STATE_PAUSED:
                self.ui.draw_pause_overlay(
                    surface=self.screen,
                    origin_x=self.origin_x,
                    origin_y=self.origin_y,
                    cell_size=self.cell_size,
                    player_x=self.env.player_visual_x,
                    player_y=self.env.player_visual_y,
                    has_key=self.env.has_key,
                    hunters=self.env.hunters,
                    key_pos=self.env.key_pos,
                    exit_pos=self.env.exit_pos,
                    recommended_path=self.cached_recommended_path,
                    ai_latency_ms=latency_ms,
                    ai_status=status_text,
                    level_name=level_name,
                    level_num=getattr(self.ui, "selected_chamber_level", 1),
                )

            # 6. Draw Game Over Overlay if in GAME_OVER state
            if self.state == STATE_GAME_OVER:
                mode_name = self.env.config["name"].upper()
                mode_str = f"{self.selected_grid_size}x{self.selected_grid_size} {mode_name}"
                best_s = self.best_victory_steps if self.best_victory_steps is not None else self.env.steps
                callsign = getattr(self, "player_name", "Bravo42") or getattr(self, "current_user", "Bravo42")
                self.ui.draw_game_over_overlay(
                    surface=self.screen,
                    is_victory=self.is_victory,
                    steps=self.env.steps,
                    is_new_best=self.is_new_best_record,
                    current_level=self.selected_level,
                    player_name=callsign,
                    mode_str=mode_str,
                    best_steps=best_s,
                    has_key=self.env.has_key,
                    defeat_cause="CAPTURED BY HUNTER",
                )

        # Global Exit Confirmation Modal overlay (if triggered from in-game or paused)
        if getattr(self.ui, "show_exit_modal", False) and self.state != STATE_HOME:
            self.ui.draw_exit_modal(self.screen)

        pygame.display.flip()

    # =========================================================================
    # MAIN LOOP ENTRY POINT
    # =========================================================================
    def run(self) -> None:
        """Execute the primary 60 FPS game loop."""
        while self.is_running:
            # Enforce strict 60 FPS clock cycle
            dt = self.clock.tick(60) / 1000.0
            # Cap dt to prevent physics tunneling on OS lag spikes
            dt = min(dt, 0.05)

            self.handle_events()
            self.update(dt)
            self.render()

        pygame.quit()
        sys.exit()

    async def run_async(self) -> None:
        """Execute the primary 60 FPS game loop asynchronously (for Web / Pygbag)."""
        while self.is_running:
            dt = self.clock.tick(60) / 1000.0
            dt = min(dt, 0.05)

            try:
                self.handle_events()
                self.update(dt)
                self.render()
            except Exception as e:
                import traceback
                traceback.print_exc()

            # Yield execution back to browser JavaScript event loop
            await asyncio.sleep(0)

        pygame.quit()
